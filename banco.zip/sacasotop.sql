-- --------------------------------------------------------
-- Servidor:                     localhost
-- Versão do servidor:           5.7.26-0ubuntu0.16.04.1 - (Ubuntu)
-- OS do Servidor:               Linux
-- HeidiSQL Versão:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para caixa_eletronico
CREATE DATABASE IF NOT EXISTS `caixa_eletronico` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `caixa_eletronico`;


-- Copiando estrutura para tabela caixa_eletronico.contas
CREATE TABLE IF NOT EXISTS `contas` (
  `id_conta` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `tipo_conta` int(11) NOT NULL,
  `saldo` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_conta`),
  KEY `fk_usuario_conta` (`id_usuario`),
  KEY `fk_tipo_conta_tipo_conta` (`tipo_conta`),
  CONSTRAINT `fk_tipo_conta_tipo_conta` FOREIGN KEY (`tipo_conta`) REFERENCES `tipo_conta` (`id_tipo_conta`),
  CONSTRAINT `fk_usuario_conta` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela caixa_eletronico.contas: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `contas` DISABLE KEYS */;
INSERT INTO `contas` (`id_conta`, `id_usuario`, `tipo_conta`, `saldo`, `status`) VALUES
	(1, 1, 1, 0, 1),
	(2, 1, 2, 0, 1),
	(3, 1, 3, 0, 1);
/*!40000 ALTER TABLE `contas` ENABLE KEYS */;


-- Copiando estrutura para tabela caixa_eletronico.contass
CREATE TABLE IF NOT EXISTS `contass` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `titular` varchar(100) DEFAULT NULL,
  `cpf` varchar(50) DEFAULT NULL,
  `conta` int(11) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL,
  `saldo` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela caixa_eletronico.contass: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `contass` DISABLE KEYS */;
INSERT INTO `contass` (`id`, `titular`, `cpf`, `conta`, `senha`, `saldo`) VALUES
	(1, 'Conta Corrente', '73432237987', 321, '827ccb0eea8a706c4c34a16891f84e7b', 20),
	(2, 'Conta Poupança', '08631180971', 456, '827ccb0eea8a706c4c34a16891f84e7b', 0),
	(3, 'Conta Salário', '06872750910', 98, '827ccb0eea8a706c4c34a16891f84e7b', 0);
/*!40000 ALTER TABLE `contass` ENABLE KEYS */;


-- Copiando estrutura para tabela caixa_eletronico.historico
CREATE TABLE IF NOT EXISTS `historico` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta` int(11) DEFAULT NULL,
  `tipo` varchar(100) DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `data_operacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela caixa_eletronico.historico: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `historico` DISABLE KEYS */;
/*!40000 ALTER TABLE `historico` ENABLE KEYS */;


-- Copiando estrutura para tabela caixa_eletronico.senhas
CREATE TABLE IF NOT EXISTS `senhas` (
  `id_senha` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `senha` varchar(100) NOT NULL,
  PRIMARY KEY (`id_senha`),
  KEY `fk_senha_usuario` (`id_usuario`),
  CONSTRAINT `fk_senha_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela caixa_eletronico.senhas: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `senhas` DISABLE KEYS */;
INSERT INTO `senhas` (`id_senha`, `id_usuario`, `senha`) VALUES
	(1, 1, '4297f44b13955235245b2497399d7a93'),
	(4, 1, '4cd51e51a4225287c8bb2fa0eb4343e1'),
	(5, 1, '023281c301fceef9e6828e195047833e'),
	(6, 1, '60387e41066f561284d85268f240a55d'),
	(7, 1, '4297f44b13955235245b2497399d7a93');
/*!40000 ALTER TABLE `senhas` ENABLE KEYS */;


-- Copiando estrutura para tabela caixa_eletronico.tipo_conta
CREATE TABLE IF NOT EXISTS `tipo_conta` (
  `id_tipo_conta` int(11) NOT NULL AUTO_INCREMENT,
  `nome_conta` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tipo_conta`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela caixa_eletronico.tipo_conta: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `tipo_conta` DISABLE KEYS */;
INSERT INTO `tipo_conta` (`id_tipo_conta`, `nome_conta`) VALUES
	(1, 'Conta Corrente'),
	(2, 'Conta Poupança'),
	(3, 'Conta Salário');
/*!40000 ALTER TABLE `tipo_conta` ENABLE KEYS */;


-- Copiando estrutura para tabela caixa_eletronico.usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(100) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '0',
  `cpf` varchar(100) NOT NULL DEFAULT '0',
  `senha` varchar(250) NOT NULL DEFAULT '0',
  `tentativa_senha` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela caixa_eletronico.usuarios: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id_usuario`, `nome_usuario`, `email`, `cpf`, `senha`, `tentativa_senha`, `status`) VALUES
	(1, 'Cristhian', 'cristhianss@gmail.com', '08631180971', '4297f44b13955235245b2497399d7a93', 0, 1),
	(2, 'Teste', 'teste@teste.com.br', '73432237987', '123123', 0, 1);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
